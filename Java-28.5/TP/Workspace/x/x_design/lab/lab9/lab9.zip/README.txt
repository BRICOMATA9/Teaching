
Instructions for running RMI source code examples.
--------------------------------------------------

This is organized into two directories:

(1) client - which contains the RMIClient code.

(2) server - which contains the RemoteDate interface and implementation.


To run the remote date  files

SERVER
------
1. Compile all source files.

2. Generate the stub and skeleton class files using RMIC.

	rmic RemoteDateImpl

3. Start the registry (rmiregistry)

On UNIX/Linux/OS X, enter

	rmiregistry &

On Windows, enter

	start rmiregistry

4. Create the remote object 

	java RMIServer	

This registers the remote date on the server with the RMI registry.

CLIENT
------

1. Copy the files 

	RemoteDate.class 

and 
	RemoteDateImpl_Stub.class 

to the client directory.

2. Compile RemoteDate.java

3. Start the client

	java RMIClient

