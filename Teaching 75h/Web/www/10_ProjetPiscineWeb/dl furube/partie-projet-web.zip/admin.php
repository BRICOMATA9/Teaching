<?php
session_start();
$nom_admin =isset($_POST["nom_admin"])? $_POST["nom_admin"] : "";
$database= "projetweb";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if($db_found)
{
  $sql = "SELECT * FROM `admin`";
}
else 
{
  echo "Database not found";
}

$result = mysqli_query($db_handle, $sql);

if (mysqli_num_rows($result) == 0) 
{
    echo "admin not found";
} 
else 
{
  while ($data = mysqli_fetch_assoc($result)) 
  {
    $nom_admin=$data["nom_admin"];
  }
}

?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="admin.css">
<body>
   <div id="header">
    <br>
     <h1>Bienvenue dans la page Administrateur</h1>
   </div>
   <div id="conteneur">
       <div id="liste">
           <ul>
            <br>
               <li>
                   Nom de l'administrateur: <?php echo $nom_admin?>
               </li>
            <br>
              <li>
                  Email administrateur: <?php echo $_SESSION['email'];?>
              </li>
           </ul>
       </div>
       <br><br>
       <div class="d-flex justify-content-center">
          <input type="button" value="Ajouter ou supprimer un Item" class="btn float-right btn-ajout" name="ajoutitem" onclick="document.location.href='http://127.0.0.1/ajoutsuppitem.php';">
    </div>
    <br><br>
       <div class="d-flex justify-content-center">
          <input type="submit" value="Ajouter ou supprimer un vendeur" class="btn float-right btn-ajout" name="ajoutvendeur" onclick="document.location.href='http://127.0.0.1/ajoutsuppitem.php';">
    </div>

   </div>
</body>