package Modèle;
//Exception instrument inexistant
public class InstruInexistant extends Exception {
	public InstruInexistant() {
		System.out.println("Instru non existante");
	}

}
