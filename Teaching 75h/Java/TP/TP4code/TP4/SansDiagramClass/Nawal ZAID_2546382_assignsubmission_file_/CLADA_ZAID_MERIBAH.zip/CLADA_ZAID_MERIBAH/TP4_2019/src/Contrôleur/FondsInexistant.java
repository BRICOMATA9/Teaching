package Contrôleur;

/**
 *
 * @author @author Idris MERIBAH,Michel CLADA,Nawal ZAID
 */
public class FondsInexistant extends Exception 
{

}
