package Contrôleur;

/**
 *
 * @author Idris MERIBAH,Michel CLADA,Nawal ZAID
 */
public class FondsExistant extends Exception 
{

}
