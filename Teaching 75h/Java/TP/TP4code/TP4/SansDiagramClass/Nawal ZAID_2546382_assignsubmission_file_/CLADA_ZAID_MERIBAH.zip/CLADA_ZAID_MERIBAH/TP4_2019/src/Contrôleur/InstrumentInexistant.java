package Contrôleur;

/**
 *
 * @author @author Idris MERIBAH,Michel CLADA,Nawal ZAID
 */
public class InstrumentInexistant extends Exception 
{

}
