/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

/**
 *
 * @author segado
 */
public class ImpossibleMoveException extends Exception { 
} 

