/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 * *Classe exception pour les fonds inexistant

 * @author Jean Leroy
 */
public class ExceptionFondInexistant extends Exception {
    public ExceptionFondInexistant ()
    {
        System.out.println("Fonds Inexistant");
    }
            
    
}
