package model;

public class Fonds implements Comparable<Fonds> {
    private double m_amount;

    public Fonds() {
    }

    /**
     *
     * @param amount
     */
    public Fonds(double amount) {
        m_amount = amount;
    }

    public double m_amount() {
        return m_amount;
    }

    /**
     *
     * @param acomparer
     * @return
     */
    public boolean equals(Fonds acomparer) {
        boolean retval;
        if (this.m_amount() == acomparer.m_amount()) {
            retval = true;
            System.out.println("equals : true");
        } else {
            retval = false;
            System.out.println("equals : false");
        }
        return retval;
    }


    @Override
    public int compareTo(Fonds acomparer) {
        int retval = 2;

        if (this.m_amount > acomparer.m_amount() || this.m_amount() < acomparer.m_amount()) {
            if (this.m_amount() > acomparer.m_amount()) {
                retval = 1;
                System.out.println("compareTo : sup");
            }
            if (this.m_amount() < acomparer.m_amount()) {
                retval = -1;
                System.out.println("compareTo : inf");
            }
        } else {
            if (this.equals(acomparer) == true) {
                retval = 0;
                System.out.println("compareTo : egal");
            }
        }

        return retval;
    }

    /**
     *
     * @return
     */
    public double getM_amount(){return m_amount;}
}
