package controller;

import Exceptions.FondsExistant;
import Exceptions.FondsInexistant;
import Exceptions.InstrumentInexistant;
import View.DisplayStats;
import model.*;
import java.util.*;

public class Tp4 {

    public static void main(String[] args) {
        Portefeuille monPortefeuille = new Portefeuille();

        int input = 1;
        do {
            System.out.println("1. Ajouter un fonds d'investissement à votre portefeuille ");
            System.out.println("2. Ajouter un instrument à votre portefeuille ");
            System.out.println("3. Ajouter un fonds à un instrument de votre portefeuille ");
            System.out.println("4. Rechercher les fonds d'un instrument dans votre portefeuille ");
            System.out.println("5. Rechercher un fonds d'investissement dans votre portefeuille ");
            System.out.println("6. Supprimer un fond d'investissement de votre portefeuille ");
            System.out.println("7. Supprimer un instrument de votre portefeuille ");
            System.out.println("8. Trier les fonds d'un instrument par ordre croissant");
            System.out.println("9. Afficher tous mes instruments leurs fonds, le nombre de fonds, et la somme des fonds par instrument");
            System.out.println("0. Quitter ");

            Scanner sc = new Scanner(System.in);
            input = sc.nextInt();
            switch (input) {
            case 1: {
                System.out.println("Entrez un montant pour votre nouveau fond d'investissment : ");
                Scanner scsw = new Scanner(System.in);
                double amount = scsw.nextDouble();
                System.out.println("Entrer une nouvelle cle pour ce fond d'investissement :");
                Scanner sckey = new Scanner(System.in);
                String key = sckey.nextLine();
                try {
                    monPortefeuille.addFonds(key, amount);
                } catch (FondsExistant fe) {
                    System.out.println("" + fe);
                }

            }
                break;

            case 2: {
                System.out.println("Quelle est la clé de votre nouvel instrument ?");
                Scanner kbkey = new Scanner(System.in);
                String key = kbkey.nextLine();
                System.out.println("Vous créez un nouvel instrument : Veuillez saisir le montant de son premier fonds");
                Scanner kbnum = new Scanner(System.in);
                double amount = kbnum.nextDouble();

                Fonds newFonds = new Fonds(amount);
                monPortefeuille.newIns(key, newFonds);
            }
                break;
            case 3: {
                System.out.println("Quelle est la clé de l'instrument dans lequel vous voulez stocker ce fonds ?");
                Scanner kbkey = new Scanner(System.in);
                String key = kbkey.nextLine();
                System.out.println("Entrer le montant du nouveau fond");
                Scanner kbnum = new Scanner(System.in);
                double amount = kbnum.nextDouble();

                Fonds newFonds = new Fonds(amount);
                monPortefeuille.newFondToIns(key, newFonds);

            }
                break;

            case 4: {
                System.out.println("Quelle est la clé de votre instrument ?");
                Scanner scsw = new Scanner(System.in);
                String key = scsw.nextLine();
                try {
                    ArrayList<Fonds> monIns = monPortefeuille.searchIns(key);
                    for (int i = 0; i < monIns.size(); i++) {
                        System.out.println("Liste de Fonds d'un instrument : " + monIns.get(i).m_amount());
                    }
                } catch (InstrumentInexistant i) {
                    System.out.println("" + i);
                }
            }
                break;

            case 5: {
                System.out.println("Quelle est la clé de votre fond d'investissement dans votre portefeuille ?");
                Scanner scsw = new Scanner(System.in);
                String key = scsw.nextLine();
                try {
                    System.out.println("Montant du Fonds recherché : " + monPortefeuille.searchFonds(key));
                } catch (FondsInexistant f) {
                    System.out.println("" + f);
                }

            }
                break;

            case 6: {
                System.out.println("Entrez la clé du fonds à supprimer");
                Scanner kbkey = new Scanner(System.in);
                String key = kbkey.nextLine();
                monPortefeuille.deleteFonds(key);
            }
                break;

            case 7: {
                System.out.println("Entrez la clé de l'instrument à supprimer");
                Scanner kbkey = new Scanner(System.in);
                String key = kbkey.nextLine();
                monPortefeuille.deleteIns(key);
            }
                break;

            case 8: {
                System.out.println("Quelle est la clé de l'instrument dont vous souhaitez trier les fonds ?");
                Scanner kbkey = new Scanner(System.in);
                String key = kbkey.nextLine();
                monPortefeuille.getMapIns(key).sortFonds();
                System.out.println("Montants des Fonds de votre instrument triés ! Les voici dans l'ordre croissant :");
                for (int i = 0; i < monPortefeuille.getMapIns(key).getListFonds().size(); i++) {
                    System.out.println(monPortefeuille.getMapIns(key).getListFonds().get(i).m_amount());
                }
            }
                break;

                case 9:{
                    DisplayStats.statsIns(monPortefeuille);
                }
            }
        } while (input != 0);
    }
}
