package Exceptions;

public class FondsExistant extends Exception{
    public FondsExistant(String key)
    {
        System.err.println("Le fonds existe déjà dans votre portefeuille, voici sa clé : "+key);
    }
}
