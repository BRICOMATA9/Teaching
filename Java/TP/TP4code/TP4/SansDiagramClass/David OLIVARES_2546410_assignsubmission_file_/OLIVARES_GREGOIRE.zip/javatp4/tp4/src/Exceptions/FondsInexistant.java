package Exceptions;

public class FondsInexistant extends Exception{
    public FondsInexistant(String key)
    {
        System.err.println("Erreur ! : Fonds Inexistants dans le portefeuille à la clé : " +key);
    }
}
