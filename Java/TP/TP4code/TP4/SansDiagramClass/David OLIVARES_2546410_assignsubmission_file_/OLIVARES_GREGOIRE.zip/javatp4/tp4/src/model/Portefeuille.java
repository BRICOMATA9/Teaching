package model;

import Exceptions.*;
import java.util.*;

public class Portefeuille {
    private HashMap<String, Fonds> m_mapFonds;
    private HashMap<String, Instrument> m_mapIns;

    public Portefeuille() {
        m_mapFonds = new HashMap<>();
        m_mapIns = new HashMap<>();
    }

    /**
     *
     * @param key
     * @return
     * @throws FondsInexistant
     */
    public double searchFonds(String key) throws FondsInexistant {
        Fonds fond = null;
        fond = m_mapFonds.get(key);
        if (fond == null) {
            throw new FondsInexistant(key);
        } else {
            System.out.println("Fonds trouvé à la clé : " + key);
        }

        return fond.m_amount();
    }

    /**
     *
     * @param key
     * @return
     * @throws InstrumentInexistant
     */
    public ArrayList<Fonds> searchIns(String key) throws InstrumentInexistant {
        Instrument ins = null;

        ins = m_mapIns.get(key);
        if (ins == null) {
            throw new InstrumentInexistant(key);
        } else {
            System.out.println("Instrument trouvé à la clé : " + key);
        }

        return ins.getListFonds();
    }

    /**
     *
     * @param newKey
     * @param fondsAmount
     * @throws FondsExistant
     */
    public void addFonds(String newKey, double fondsAmount) throws FondsExistant {
        double fond = -1;
        try {
            fond = this.searchFonds(newKey);

        } catch (FondsInexistant f) {
            System.out.println("" + f);
            Fonds newFond = new Fonds(fondsAmount);
            m_mapFonds.put(newKey, newFond);
        }

    }

    /**
     *
     * @param newKey
     * @param newFonds
     */
    public void newIns(String newKey, Fonds newFonds) {
        ArrayList<Fonds> ins = null;

        try {
            ins = this.searchIns(newKey);
        } catch (InstrumentInexistant ie) {
            System.out.println("" + ie);
        } finally {
            Instrument newIns = new Instrument(newFonds);
            m_mapIns.put(newKey, newIns);
        }
    }

    /**
     *
     * @param key
     * @param newFonds
     */
    public void newFondToIns(String key, Fonds newFonds) {
        try {
            this.searchIns(key);
            m_mapIns.get(key).addNewFonds(newFonds);
        } catch (InstrumentInexistant ie) {
            System.out.println("" + ie);
        }
    }

    /**
     *
     * @param key
     */
    public void deleteFonds(String key) {
        try {
            this.searchFonds(key);
            m_mapFonds.remove(key);
        } catch (FondsInexistant f) {
            System.out.println("" + f);
        }

    }

    /**
     *
     * @param key
     */
    public void deleteIns(String key) {
        try {
            this.searchIns(key);
            m_mapIns.get(key).clearListFonds();
            m_mapIns.remove(key);
        } catch (InstrumentInexistant i) {
            System.out.println("" + i);
        }
    }

    /**
     *
     * @param key
     * @return
     */
    public Instrument getMapIns(String key) {
        return m_mapIns.get(key);
    }

    /**
     *
     * @return
     */
    public HashMap<String, Fonds> getM_mapFonds() {
        return m_mapFonds;
    }

    /**
     *
     * @return
     */
    public HashMap<String, Instrument>getM_mapIns() {return  m_mapIns;}

}
