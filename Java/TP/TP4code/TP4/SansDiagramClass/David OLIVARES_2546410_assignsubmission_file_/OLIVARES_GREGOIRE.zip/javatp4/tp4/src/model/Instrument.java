package model;

import java.util.ArrayList;
import java.util.Collections;

public class Instrument {
    private ArrayList<Fonds> m_fonds;

    public Instrument()
    {
        m_fonds = new ArrayList<>();
        Fonds unFond = new Fonds(400);
        m_fonds.add(unFond);
    }

    /**
     *
     * @param newFonds
     */
    public Instrument(Fonds newFonds)
    {
        m_fonds = new ArrayList<>();
        m_fonds.add(newFonds);
    }

    /**
     *
     * @param newFonds
     */
    public void addNewFonds(Fonds newFonds)
    {
        m_fonds.add(newFonds);
    }


    public void clearListFonds()
    {
        m_fonds.clear();
    }

    public void sortFonds()
    {
        Collections.sort(m_fonds);
    }

    public ArrayList<Fonds> getListFonds()
    {
        return m_fonds;
    }
}
