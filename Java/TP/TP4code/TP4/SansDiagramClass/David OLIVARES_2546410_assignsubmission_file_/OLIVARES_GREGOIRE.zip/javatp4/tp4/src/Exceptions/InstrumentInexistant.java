package Exceptions;

public class InstrumentInexistant extends Exception {

    public InstrumentInexistant(String key)
    {
        System.err.println("Instrument Inexistant à la clé : "+key);
    }
}
