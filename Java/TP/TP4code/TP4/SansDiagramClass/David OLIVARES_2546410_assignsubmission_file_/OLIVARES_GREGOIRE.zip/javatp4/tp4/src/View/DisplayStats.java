package View;

import model.Fonds;
import model.Portefeuille;
import  java.util.*;

public abstract class DisplayStats {

    public static void  statsIns(Portefeuille portefeuille)
    {

        for(String name: portefeuille.getM_mapIns().keySet())
        {
            double somme = 0;
            String key = name.toString();
            System.out.println("Clé de l'instrument : "+key);
            ArrayList<Fonds> value = portefeuille.getMapIns(name).getListFonds();
            System.out.println("Nombre de fonds :"+value.size());

            for(int i=0; i<value.size(); i++)
            {
                System.out.println(value.get(i).getM_amount());
                somme += value.get(i).getM_amount();
            }
            System.out.println("Somme des montants des fonds : "+somme);
        }
    }
}
