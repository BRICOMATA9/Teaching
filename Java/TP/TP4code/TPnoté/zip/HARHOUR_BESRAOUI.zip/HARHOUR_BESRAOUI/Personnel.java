import java.util.Date;
import java.util.ArrayList;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employe;

/**
 *
 * @author Amine
 */
public class Personnel {
    private Arraylist<Employes>Employes;
    public Personnel(){
        this.Employes=new Arraylist <Emp>();
    }
    public void AjouterEmp(Emp e){
        this.Emp.add(e);
    }
    public void calculerHoraire (int sem){
        for(Employes e; this.Employes){
            System.out.println(getNom+""+calculerHoraire(sem))
        }
    }
}
