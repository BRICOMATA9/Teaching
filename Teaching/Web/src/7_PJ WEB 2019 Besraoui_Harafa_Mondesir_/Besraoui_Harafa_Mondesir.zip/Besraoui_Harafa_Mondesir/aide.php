<?php

require_once("../Première version ECEAmazon/hearder.php"); 
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aide</title>
	<link rel="stylesheet" type="text/css" href="aide.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	
    <div id="colonne1">
    	<img src="commandes.jpg" width="100" height="100">
    	<a href="http://localhost/Première version ECEAmazon/commandes.php">Vos Commandes</a>
    </div>


    <div id="colonne2">
        <img src="retour et remboursement.jpg" width="100" height="100">
    	<a href="http://localhost/Première version ECEAmazon/RetouretRemboursements.php">Retour et Remboursements</a>
    </div>


    <div id="colonne3">
        <img src="option de paiement.jpg" width="100" height="100">
    	<a href="http://localhost/Première version ECEAmazon/optiondePaiement.php">Options de Paiement</a>
    </div>

    <div id="colonne4">
        <img src="paramètres du compte.jpg" width="100" height="100">
    	<a href="http://localhost/Première version ECEAmazon/parametreduCompte.php">Paramètres du Compte</a>
    </div>
    

</body>

</html>