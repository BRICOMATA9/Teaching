<?php 
require_once("../Première version ECEAmazon/hearder.php"); 

?>

<!DOCTYPE html>
<html>
<head>
	<title>Options de paiement</title>
	<meta charset="utf-8">
	<!-- On inclue le CSS ici pour éviter de créer une page CSS en plus -->
	<style type="text/css">



</style>
</head>
<body>
	

<!-- Texte -->
	   <h1> Options de paiement </h1>

<p>Vos cartes de paiement</p>
<br><br>
<p>Vos cheques cadeaux<p>
<br><br>
<p>Modifier la methode de paiement pour une commande en cours<p>
<br><br>



	    

</body>
</html>