<?php
  require_once("../Première version ECEAmazon/hearder.php"); 

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Livre</title>
	<link rel="stylesheet" type="text/css" href="designaccueil.css">
	<link rel="stylesheet" type="text/css" href="livre.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
        
    

</head>
<body>

	

		<a href="http://localhost/Première version ECEAmazon/ajout.php"><input type="button" name="ajouter" value="ajouter"></a>
		<a href="http://localhost/Première version ECEAmazon/supprime.php"><input type="button" name="supprimer" value="supprimer"></a>
	

	

</body>
</html>