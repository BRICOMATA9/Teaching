<html>
<head>
      <title>Projet WEB</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
      <link rel="stylesheet" type="text/css" href="hearder.css">
</head> 
    <body>
      <nav class="navbar navbar-expand-md">
       <a href="http://localhost/Première version ECEAmazon/accueil.php"><img src="logo_ece_amazon1.png" alt="Acceuil" width="150" height="100"/></a> 
      <button class="navbar-toggler navbar-dark" type="button" datatoggle="collapse" data-target="#main-navigation">
             <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="main-navigation">
           <ul class="navbar-nav">
               <li class="nav-item"><a class="nav-link" href="http://localhost/Première version ECEAmazon/categories.php">Catégories</a></li>
               <li class="nav-item"><a class="nav-link" href="http://localhost/Première version ECEAmazon/ventes_flash.php">Ventes flash</a></li>
               <li class="nav-item"><a class="nav-link" href="http://localhost/Première version ECEAmazon/vendeur.php">Vendre</a></li>
               <li class="nav-item"><a class="nav-link" href="http://localhost/Première version ECEAmazon/votre_compte.php">Votre Compte</a></li>
               <li class="nav-item"><a class="nav-link" href="http://localhost/Première version ECEAmazon/aide.php">Aide</a></li>
               <li class="nav-item"><a class="nav-link" href="#"></a>
                  <a href="http://localhost/Première version ECEAmazon/panier.php"><img src="panier.png" alt="Panier" width="70" height="50"/>Panier</a> 
                     <button class="navbar-toggler navbar-dark" type="button" datatoggle="collapse" data-target="#main-navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>
               </li>
               <li class="nav-item"><a class="nav-link" href="http://localhost/Première version ECEAmazon/admin.php">Admin</a></li>
           </ul>
      </div>
      </nav>
      <!-- Footer -->
      <div id="footer">Copyright &copy; 2019 ECE Amazon<br>   
           <a href="mailto:ece_amazon_contact@gmail.com">ece_amazon_contact@gmail.com </a> 
      </div>

    </body>
  <header class="page-header header container-fluid">
    <div class="overlay"></div>
    <div class="description"></div>
  </header>
</html>