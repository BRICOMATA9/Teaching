<?php

$database = "ece_amazon";

?>