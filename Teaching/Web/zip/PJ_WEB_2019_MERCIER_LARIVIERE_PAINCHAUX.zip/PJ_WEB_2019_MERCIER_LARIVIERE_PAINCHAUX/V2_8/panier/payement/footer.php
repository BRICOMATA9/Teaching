<!DOCTYPE html>
<!--
	Auteurs : Clément LARIVIERE	TD10
			  Théo MERCIER		TD04
			  Antoine PAINCHAUX TD01
-->
<html lang="fr">

<footer class="container">
	<p>&copy; Amazon ECE 2019</p>
</footer>

</html>