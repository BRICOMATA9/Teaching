public class NullLog implements Log
{
	public void logMessage(String message) {
		// "Nothing will come of nothing." - King Lear
	}
}
