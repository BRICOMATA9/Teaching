@SuppressWarnings ("serial")
public final class FullException extends RuntimeException
{
	public FullException (String msg)
	{ 
		super (msg);
	}
}
