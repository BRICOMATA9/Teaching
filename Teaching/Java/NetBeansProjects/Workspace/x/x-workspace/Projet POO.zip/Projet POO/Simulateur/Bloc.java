public interface Bloc{
	public int getTaille(); 	//retourne la taille du Bloc
	public String getNom();		//retourne le nom du Bloc
	public String toString();	//pour afficher la taille du Bloc
}
