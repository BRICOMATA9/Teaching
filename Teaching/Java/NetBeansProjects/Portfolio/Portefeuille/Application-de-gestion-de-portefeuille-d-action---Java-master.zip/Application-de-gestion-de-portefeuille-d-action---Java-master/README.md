# Java - Application de gestion de portefeuille d'action
Projet de développement d'un application de gestion de portefeuille d'actions en Java.
Le projet est réalisé sous l'IDE Eclipse. Les fichiers sources ainsi que les images sont néanmoins récupérables.
