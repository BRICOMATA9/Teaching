import java.lang.Math;
import javax.swing.JOptionPane;
public class DEVINETTE  {
	private int val;
    int i=0;
     int nb=0;
   
	public DEVINETTE()
	{val=(int)(Math.random()*100);}
	
	public void go(int num )
	{
		 if (num<val){ JOptionPane.showMessageDialog(null,"trop petit!");nb++;}
		 if (num>val){ JOptionPane.showMessageDialog(null,"trop grand!");nb++;}
		 if (num==val){ JOptionPane.showMessageDialog(null,"Vous Avez Gangnez \n apres"+nb+"coups");
		 if(JOptionPane.showConfirmDialog(null, "Rejouer","Rejouer",0)==1)System.exit(0);
		 else nb=0;}
		 if ((nb >= 7)&& (num!=val)){ JOptionPane.showMessageDialog(null,"GAME OVER VOUS AVEZ PERDUS!");
		 if(JOptionPane.showConfirmDialog(null, "Rejouer","Rejouer",0)==1)System.exit(0);
		 
		 else nb=0;
		 }
	}
}