public interface Controller {
    public void processModel(Model model, String input);
}