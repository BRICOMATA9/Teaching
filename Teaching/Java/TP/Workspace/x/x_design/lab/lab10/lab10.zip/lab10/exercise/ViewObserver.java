public interface ViewObserver
{
  void updateView(String message);
}