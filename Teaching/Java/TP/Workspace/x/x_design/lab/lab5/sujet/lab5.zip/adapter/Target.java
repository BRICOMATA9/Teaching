/**
 * This is the interface the client expects.
 */

public interface Target
{
	public abstract void request(); 
}
