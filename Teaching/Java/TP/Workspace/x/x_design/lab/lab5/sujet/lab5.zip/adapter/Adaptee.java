public class Adaptee
{
	public void delegatedRequest() {
		System.out.println("This is the delegated method.");
	}
}
