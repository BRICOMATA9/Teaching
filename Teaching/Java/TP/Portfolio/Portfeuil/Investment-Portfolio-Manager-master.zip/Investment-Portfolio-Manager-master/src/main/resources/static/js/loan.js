/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var DateTime = luxon.DateTime;
dataSet = [];
dataTable = {};
function calaculateLoanSummary() {
    totInterest = 0;
    startDate = $("#startDate").val();
    loanName = $("#loanName").val();
    amount = $("#amount").val();
    air = $("#air").val();
    years = $("#years").val();
    payments = $("#payments").val();
    optionalPay = $("#optionalPay").val();
    npay = years * payments;
    monthlyInterestRatio = air / 100 / payments;
    var top = Math.pow(1 + monthlyInterestRatio, npay);
    var bottom = top - 1;
    var sp = top / bottom;
    emi = amount * monthlyInterestRatio * sp;
    var full = npay * emi;
    var interest = full - amount;
    $("#schPay").val(toAmountInRs(emi));
    $("#schNumPay").val(npay);
    $("#actNumPay").val('');
    $("#totEarPay").val('');
    $("#totInt").val(toAmountInRs(interest));
    loanTable();
}

function loanTable() {
    balance = amount;
    nexDate = startDate;
    i = 1;
    dataTable.clear().draw();
    while (balance > 0) {
        interest = balance * monthlyInterestRatio;
        total = parseInt(emi.toFixed(0)) + parseInt(optionalPay);
        principal = total - interest;
        balance = balance - principal;
        totInterest += interest;
        var d = DateTime.fromISO(nexDate);
        nexDate = d.plus({months: 1}).toISODate();
        nexRow = [i++, nexDate, parseInt(balance + principal), parseInt(emi.toFixed(0)), parseInt(optionalPay), total, principal, interest, balance, totInterest];
        console.log(nexRow);
        addedRow = dataTable.row.add(nexRow).draw();
    }
}

function toAmountInRs(value) {
    return value.toFixed(0)
            .toString()
            .replace(/,/g, "")
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

$(document).ready(function () {
    var today = new Date();
    $("#startDate").val(today.toISOString().substr(0, 10));
    $("#loanName").val('HDFC');
    $("#amount").val(4800000);
    $("#air").val(9);
    $("#years").val(24);
    $("#payments").val(12);
    $("#optionalPay").val(2000);
    //[P x R x (1+R)^N]/[(1+R)^N-1]
    dataTable = $('#example').DataTable({
        data: dataSet,
        columns: [
            {title: 'Pmt No'},
            {title: 'Payment Date'},
            {title: 'Beginning Balance'},
            {title: 'Scheduled Payment'},
            {title: 'Extra Payment'},
            {title: 'Total Payment'},
            {title: 'Principal'},
            {title: 'Interest'},
            {title: 'Ending Balance'},
            {title: 'Cumulative Interest'}
        ]
    });
    $("#details").submit(function (event) {
        event.preventDefault();
        calaculateLoanSummary();
    });
});
