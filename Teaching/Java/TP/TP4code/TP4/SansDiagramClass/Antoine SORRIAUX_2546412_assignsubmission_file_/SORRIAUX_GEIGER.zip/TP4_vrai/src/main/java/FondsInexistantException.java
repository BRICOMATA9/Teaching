/*
 * FONDS INEXISTANT 
 * EXCEPTION
 */

/**
 *
 * @author antoinesorriaux et thomasgeiger
 */
public class FondsInexistantException extends Exception {
    
    
    public FondsInexistantException() {
        
        System.out.println("Exception : FondInexistant");
        
        
    }
    
}
