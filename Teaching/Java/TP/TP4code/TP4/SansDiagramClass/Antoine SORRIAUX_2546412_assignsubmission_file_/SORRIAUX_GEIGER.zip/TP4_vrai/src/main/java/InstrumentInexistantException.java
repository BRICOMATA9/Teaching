/*
 * INSTRUMENT INEXISTANT 
 * EXCEPTION
 */

/**
 *
 * @author antoinesorriaux et thomasgeiger
 */
public class InstrumentInexistantException extends Exception{
    
    public InstrumentInexistantException(){
        
        System.out.println("Exception : Instrument Inexistant");
        
    }
    
}
