/*
 * FONDS EXISTANT
 * EXCEPTION
 */

/**
 *
 * @author antoinesorriaux et thomasgeiger
 */
public class FondsExistantException extends Exception {
    
    public FondsExistantException(){
        System.out.println("Exception : FondExistant");
    }
    
}
