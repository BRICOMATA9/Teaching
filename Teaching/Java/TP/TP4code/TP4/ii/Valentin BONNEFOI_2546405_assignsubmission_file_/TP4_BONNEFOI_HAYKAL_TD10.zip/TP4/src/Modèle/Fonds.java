/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modèle;

/**
 *
 * @author valentin
 */
public class Fonds {
    
   private double amount;
    
    public Fonds(){
    
    amount = 0;
    }
    
    
    public Fonds(double f_amount){
    
    amount = f_amount;
    }
    
    
    public double getA(){

return amount;
}
    
    
  
    
    
}
