package Modele;
/**
 * 
 * @author Cl�ment Larivi�re
 * @author Lucie Sternberger
 * Classe : <b>FondExistantException</b>
 * Exception lorsqu'un fond est existant
 */
@SuppressWarnings("serial")
public class FondExistantException extends Exception
{
	public FondExistantException() 
	{
		
	}
}
