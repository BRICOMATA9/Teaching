package Modele;
/**
 * 
 * @author Cl�ment Larivi�re
 * @author Lucie Sternberger
 * Classe : <b>InstrumentInexistantException</b>
 * Exception lorsqu'un objet est inexistant
 */
@SuppressWarnings("serial")
public class InstrumentInexistantException extends Exception 
{
	public InstrumentInexistantException() 
	{
		
	}

}
