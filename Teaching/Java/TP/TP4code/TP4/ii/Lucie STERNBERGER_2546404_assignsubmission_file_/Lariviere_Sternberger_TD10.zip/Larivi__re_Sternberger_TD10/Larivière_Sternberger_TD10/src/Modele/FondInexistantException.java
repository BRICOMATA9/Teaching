package Modele;
/**
 * 
 * @author Cl�ment Larivi�re
 * @author Lucie Sternberger
 * Classe : <b>FondInexistantException</b>
 * Exception lorsqu'un fond est inexistant
 */
@SuppressWarnings("serial")
public class FondInexistantException extends Exception 
{
	public FondInexistantException() 
	{
		
	}

}
