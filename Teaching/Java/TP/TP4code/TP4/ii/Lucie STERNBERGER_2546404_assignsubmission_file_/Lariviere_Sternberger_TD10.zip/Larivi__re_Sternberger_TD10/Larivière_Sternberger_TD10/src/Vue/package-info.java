/**
 * @author Cl�ment Larivi�re
 * @author Lucie Sternberger
 *
 */
package Vue;