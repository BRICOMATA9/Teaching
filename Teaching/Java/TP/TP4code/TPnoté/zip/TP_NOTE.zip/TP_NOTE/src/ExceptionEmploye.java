public class ExceptionEmploye 
{

}
