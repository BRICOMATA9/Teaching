/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpnote;

/**
 * Classe ExceptionEmploye créée qui hérite de la classe Exception
 * @author margo
 */
public class ExceptionEmploye extends Exception{
    /**Exception employe qui affiche un message */
    public ExceptionEmploye(){
        System.out.println("ExceptionEmploye");
    }
   
}
